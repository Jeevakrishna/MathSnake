using UnityEngine;

public class BridgeScriptForRetainingObjects : MonoBehaviour
{
    public const string bridgeObjectName = "BridgeGameObject";

    public GameObject canvasGO;
    public GameObject nestedCanvasGO;
}
