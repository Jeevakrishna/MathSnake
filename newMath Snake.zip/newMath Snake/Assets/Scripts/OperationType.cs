public enum OperationType
{
    Addition,
    Subtraction,
    Multiplication,
    Division
}